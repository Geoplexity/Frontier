/**
 * Title:        SKPointSubShape
 * Description:  This is for objects that use point(s) (ie SKLineShape, etc)
 */
   package sketcher;

   import java.awt.Graphics;

   public class SKPointSubShape extends SKPointShape
   {
      public SKBaseShape parentShape;
   
      public SKPointSubShape(SKMainFrame frame, int id, int x, int y, SKBaseShape parent)
      {
         super(frame,id,x,y);
         parentShape = parent;
      }
   
      public void paintSpecial(Graphics g)
      {
         super.paintSpecial(g);
      
         if (parentShape.isPrimaryShape(this))
            parentShape.paintSpecial(g);
      }
   
      public SKBaseShape getSelectable()
      {
         return parentShape.getSelectable();
      }
   
      public void repaint()
      {
         super.repaint();
      
      //This needs to call even if it is not the primary subshape for selection, etc
         parentShape.repaint();
      }
   }