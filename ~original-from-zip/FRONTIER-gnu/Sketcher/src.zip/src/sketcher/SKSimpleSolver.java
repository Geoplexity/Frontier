/**
 * Title:        SKSimpleSolver
 * Description:  Used for automatic solving of "simple" constraints
 */
   package sketcher;

   import java.awt.Point;

   public class SKSimpleSolver
   {
      public static void ResolveSimpleConstraints(SKBaseShape shape, SKConstraintArray cons)
      {
         SKBaseConstraint con;
         for (int i=0; i<shape.ConstraintList.size(); i++)
         {
            con = shape.ConstraintList.get(i);
            if (cons.indexOf(con) == -1)
            {
               DoSimpleSolver(con,shape,cons);
            }
         }
      }
   //Solves 1 constraint (preserving the position of 1 shape)
      public static boolean DoSimpleSolver(SKBaseConstraint con, SKBaseShape preservedShape, SKConstraintArray cons)
      {
         if (preservedShape==null)  preservedShape = con.ShapeList.get(0);
         cons.add(con);
         boolean res = true;
         //System.out.println(con.typeID);
         switch (con.typeID)
         {
            case 1 : 
               { //Incidence
                  int i,g;
                  SKBaseShape sh;
                  for (i=0; i<con.ShapeList.size(); i++)
                     if (con.ShapeList.get(i) != preservedShape)
                     {
                        sh = con.ShapeList.get(i);
                        Point pt1,pt2;
                        g = con.getConInfo(sh,0);
                        pt1 = sh.getConstraintPoint(con,g);
                        pt2 = preservedShape.getConstraintPoint(con,con.getConInfo(preservedShape,0));
                        if (!pt1.equals( pt2 ))
                        {
                           sh.setConstraintPoint(con,g,pt2);
                           ResolveSimpleConstraints(sh,cons);
                        }
                     }
               }
               break;
            case 2: 
               { //Perpendicular
                  SKPointShape ppt2 = ((SKLineShape)preservedShape).getTopPoint(),
                  ppt1 = ((SKLineShape)preservedShape).getOtherPoint(ppt2);
                  SKPointShape spt1, spt2;
                  double s1x,s1y,s2x,s2y,sSlope,dsq;
                  double p1x = ppt1.getX(),
                  p1y = ppt1.getY(),
                  p2x = ppt2.getX(),
                  p2y = ppt2.getY(),
                  pSlope = (p1y-p2y)/(p1x-p2x);
               
                  SKBaseShape sh;
                  for (int i=0; i<con.ShapeList.size(); i++)
                  {
                     sh = con.ShapeList.get(i);
                     if (sh != preservedShape)
                     {
                        spt2 = ((SKLineShape)sh).getTopPoint();
                        spt1 = ((SKLineShape)sh).getOtherPoint(spt2);
                     
                        s1x = spt1.getX();
                        s2x = spt2.getX();
                        if (p1x!=p2x)
                        {s1y = spt1.getY();
                           s2y = spt2.getY();
                           sSlope = (s1y-s2y)/(s1x-s2x);
                        
                           if ( java.lang.Math.round(pSlope*10) != java.lang.Math.round((1/sSlope)*10))
                           {
                              dsq = ((s1x-s2x)*(s1x-s2x)) + ((s1y-s2y)*(s1y-s2y));
                              double yf = -java.lang.Math.sqrt( dsq/(1+(pSlope*pSlope)) ) + s1y,
                              xf = pSlope*(s1y-yf) + s1x;
                              int   xfi = (int)java.lang.Math.round(xf),
                              yfi = (int)java.lang.Math.round(yf);
                           
                              spt2.doMove( xfi - (int)s2x, yfi - (int)s2y, false );
                              ResolveSimpleConstraints(sh,cons);
                           }
                        }
                        else
                        { //Handle undefinded case
                           s1y = spt1.getY();
                           s2y = spt2.getY();
                           if (s1y!=s2y)
                           {
                              dsq = java.lang.Math.round(java.lang.Math.sqrt(((s1x-s2x)*(s1x-s2x)) + ((s1y-s2y)*(s1y-s2y))));
                              if (s1y<s2y)
                                 spt2.doMove( (int)(s1x+dsq-s2x), (int)s1y-(int)s2y, false );
                              else
                                 spt2.doMove( (int)(s1x-dsq-s2x), (int)s1y-(int)s2y, false );
                           
                              ResolveSimpleConstraints(sh,cons);
                           }
                        }
                     }
                  }
               }
               break;
            case 3 : 
               { //Parallel
                  SKPointShape ppt1 = ((SKLineShape)preservedShape).getLeftPoint(),
                  ppt2 = ((SKLineShape)preservedShape).getOtherPoint(ppt1);
                  SKPointShape spt1, spt2;
                  double s1x,s1y,s2x,s2y,sSlope,dsq;
                  double p1x = ppt1.getX(),
                  p1y = ppt1.getY(),
                  p2x = ppt2.getX(),
                  p2y = ppt2.getY(),
                  pSlope = (p1y-p2y)/(p1x-p2x);
               
                  SKBaseShape sh;
                  for (int i=0; i<con.ShapeList.size(); i++)
                  {
                     sh = con.ShapeList.get(i);
                     if (sh != preservedShape)
                     {
                        spt1 = ((SKLineShape)sh).getLeftPoint();
                        spt2 = ((SKLineShape)sh).getOtherPoint(spt1);
                     
                        s1x = spt1.getX();
                        s2x = spt2.getX();
                        if (p1x!=p2x)
                        {
                           s1y = spt1.getY();
                           s2y = spt2.getY();
                           sSlope = (s1y-s2y)/(s1x-s2x);
                        
                           if ( java.lang.Math.round(pSlope*10) != java.lang.Math.round(sSlope*10))
                           {
                              dsq = ((s1x-s2x)*(s1x-s2x)) + ((s1y-s2y)*(s1y-s2y));
                              double xf = java.lang.Math.sqrt( dsq/(1+(pSlope*pSlope)) ) + s1x,
                              yf = -pSlope*(s1x-xf) + s1y;
                              int   xfi = (int)java.lang.Math.round(xf),
                              yfi = (int)java.lang.Math.round(yf);
                           
                              spt2.doMove( xfi - (int)s2x, yfi - (int)s2y, false );
                              ResolveSimpleConstraints(sh,cons);
                           }
                        }
                        else
                        { //Handle undefinded case
                           if (s1x!=s2x)
                           {s1y = spt1.getY();
                              s2y = spt2.getY();
                              dsq = java.lang.Math.round(java.lang.Math.sqrt(((s1x-s2x)*(s1x-s2x)) + ((s1y-s2y)*(s1y-s2y))));
                              if (s1y<s2y)
                                 spt2.doMove( (int)s1x-(int)s2x, (int)(s1y+dsq-s2y), false );
                              else
                                 spt2.doMove( (int)s1x-(int)s2x, (int)(s1y-dsq-s2y), false );
                           
                              ResolveSimpleConstraints(sh,cons);
                           }
                        }
                     }
                  }
               }
               break;
            case 4:
               {// angle
                  double slope1,slope2,c1,inc1,angle,inc2=0;
                  for (int j=0; j<con.ShapeList.size(); j++)
                  {
                     SKLineShape sh =(SKLineShape) con.ShapeList.get(j);
                     if (sh == preservedShape)
                     {
                        slope1 = (sh.pt2.getShapeY() - sh.pt1.getShapeY()) / (sh.pt2.getShapeX() - sh.pt1.getShapeX());
                        c1 = sh.pt1.getShapeY() - (slope1*sh.pt1.getShapeX());
                        inc1 = java.lang.Math.atan(slope1);
                        angle = ((SKAngleConstraint)con).angle;
                        //if(sh.pt1.getShapeY() == sh.pt2.getShapeX())
                        SKBaseShape sh1 = getOtherShape(con,sh);
                        /*if(((SKLineShape)sh1).getLeftPoint().getShapeY()<((SKLineShape)sh).getLeftPoint().getShapeY())
                           inc2 = java.lang.Math.toRadians(angle) + inc1;
                        else 
                           inc2 = inc1-angle;*/
                        inc2 = java.lang.Math.toRadians(angle) + inc1;
                        slope2 = java.lang.Math.tan(inc2);
                     }
                  }
                  for (int j=0; j<con.ShapeList.size(); j++)
                  {
                     SKLineShape sh =(SKLineShape) con.ShapeList.get(j);
                     if (sh != preservedShape)
                     {
                        SKPointShape p = sh.getTopPoint();
                        SKPointShape p1 = sh.getOtherPoint(p);
                        float dist = distance (p.getShapeX(),p.getShapeY(),p1.getShapeX(),p1.getShapeY());
                        int x,y;
                        if(inc2<90) 
                           x=(int)(p1.getShapeX() + (dist*java.lang.Math.cos(inc2)));
                        else
                           x=(int)(p1.getShapeX() - (dist*java.lang.Math.cos(inc2)));
                        y=(int)(p1.getShapeY()+(dist*java.lang.Math.sin(inc2)));
                        p.doMove((x-p.getShapeX()),(y-p.getShapeY()),false);
                        ResolveSimpleConstraints(sh,cons);
                     }
                  }
               
               }
               break;
            case 5 : 
               { //Tangent
                  if(preservedShape instanceof SKLineShape)
                  {SKCircleShape sh ;
                     SKLineShape sh1 = (SKLineShape)preservedShape;
                     double[] input = new double[8];
                     double[] output = new double[8];
                     double[] array = new double[4];
                     for (int j=0; j<con.ShapeList.size(); j++)
                     {
                        if (con.ShapeList.get(j) != preservedShape)
                        {
                           sh =(SKCircleShape) con.ShapeList.get(j);
                           int centerx = sh.center.getShapeX();
                           int centery = sh.center.getShapeY();
                           double slope,c1,c2,pslope;
                           slope =((double) (sh1.pt2.getShapeY()-sh1.pt1.getShapeY())/(double)(sh1.pt2.getShapeX()-sh1.pt1.getShapeX()));
                           pslope = -1/slope;
                           //System.out.println("s"+sh1.pt2.getShapeY()+" "+sh1.pt1.getShapeY()+" "+sh1.pt2.getShapeX()+" "+sh1.pt1.getShapeX()+" "+slope);
                           int x,y,i=0;
                           float rad;
                           if(sh.radius == -1) rad = 20;
                           else rad = (float)sh.radius;
                           if(((SKLineShape)preservedShape).pt2.getShapeY()==((SKLineShape)preservedShape).pt1.getShapeY())
                              sh.doMove(0,(int)(((SKLineShape)preservedShape).pt2.getShapeY()-centery+rad),false);
                           else 
                           {
                              c1 = (((SKLineShape)preservedShape).pt2.getShapeY() - (slope*((SKLineShape)preservedShape).pt2.getShapeX()));
                              c2 = centery - (pslope * centerx);
                              input[0] = centerx;
                              input[1] = centery;
                              input[2] = rad;
                              input[3] = pslope;
                              input[4] = c2;
                              input[5] = ((SKLineShape)preservedShape).getShapeX();
                              input[6] = ((SKLineShape)preservedShape).getShapeY();
                              circleintersection(input,output);
                              x=(int)output[0];
                              y=(int)output[1];
                              lineintersection(array,slope,pslope,c1,c2);
                              x = (int)array[0] - x;
                              y = (int)array[1] - y;
                              //System.out.println(input[0]+" "+input[1]+" "+input[2]+" "+input[3]+" "+input[4]+" "+input[5]+" "+input[6]);
                              sh.doMove(x,y,false);
                           }
                           ResolveSimpleConstraints(sh,cons);
                        }
                     }
                  }
                  else if(preservedShape instanceof SKCircleShape)
                  {
                     SKCircleShape sh1 = (SKCircleShape)preservedShape;
                     float rad, rad1;
                     if(sh1.radius == -1) rad = 20;
                     else rad = (float)sh1.radius;
                     for (int i=0; i<con.ShapeList.size(); i++)
                     {SKBaseShape sh;
                        sh = con.ShapeList.get(i);
                        if (sh != preservedShape)
                           if(sh instanceof SKCircleShape)
                           {
                              if(((SKCircleShape)sh).radius == -1) rad1 = 20;
                              else rad1 = (float)((SKCircleShape)sh).radius;
                              int centerx = ((SKCircleShape)sh).center.getShapeX();
                              int centery = ((SKCircleShape)sh).center.getShapeY();
                              double slope,c1,c2;
                              double[] input = new double[8];
                              double[] output = new double[8];
                              slope =((double) (sh1.center.getShapeY()-((SKCircleShape)sh).center.getShapeY())/(double)(sh1.center.getShapeX()-((SKCircleShape)sh).center.getShapeX()));
                              //System.out.println("s"+sh1.pt2.getShapeY()+" "+sh1.pt1.getShapeY()+" "+sh1.pt2.getShapeX()+" "+sh1.pt1.getShapeX()+" "+slope);
                              int x,y;
                              c1 = centery - (slope * centerx);
                              input[0] = centerx;
                              input[1] = centery;
                              input[2] = rad1;
                              input[3] = slope;
                              input[4] = c1;
                              input[5] = sh1.getShapeX();
                              input[6] = sh1.getShapeY();
                              circleintersection(input,output);
                              x=(int)output[0];
                              y=(int)output[1];
                              input[0] = sh1.center.getShapeX();
                              input[1] = sh1.center.getShapeY();
                              input[2] = rad;
                              input[5] = sh.getShapeX();
                              input[6] = sh.getShapeY();
                              circleintersection(input,output);
                              x = (int)output[0] - x;
                              y = (int)output[1] - y;
                              //System.out.println(input[0]+" "+input[1]+" "+input[2]+" "+input[3]+" "+input[4]+" "+input[5]+" "+input[6]);
                              sh.doMove(x,y,false);
                              ResolveSimpleConstraints(sh,cons);
                           }
                           else{
                              int centerx = ((SKCircleShape)sh1).center.getShapeX();
                              int centery = ((SKCircleShape)sh1).center.getShapeY();
                              double slope,pslope,c1,c2;
                              double[] input = new double[8];
                              double[] output = new double[8];
                              double[] array = new double[8];
                              slope =((double) (((SKLineShape)sh).pt2.getShapeY()-((SKLineShape)sh).pt1.getShapeY())/(double)(((SKLineShape)sh).pt2.getShapeX()-((SKLineShape)sh).pt1.getShapeX()));
                              pslope = -1/slope;
                           //System.out.println("s"+sh1.pt2.getShapeY()+" "+sh1.pt1.getShapeY()+" "+sh1.pt2.getShapeX()+" "+sh1.pt1.getShapeX()+" "+slope);
                              int x,y;
                              if(((SKLineShape)sh).pt2.getShapeY()==((SKLineShape)sh).pt1.getShapeY())
                                 sh.doMove(0,(int)(-((SKLineShape)sh).pt2.getShapeY()+centery+rad),false);
                              else
                              {
                                 c1 = (((SKLineShape)sh).pt2.getShapeY() - (slope*((SKLineShape)sh).pt2.getShapeX()));
                                 c2 = centery - (pslope * centerx);
                                 lineintersection(array,slope,pslope,c1,c2);
                                 x=(int)array[0];
                                 y=(int)array[1];
                                 input[0] = centerx;
                                 input[1] = centery;
                                 input[2] = rad;
                                 input[3] = pslope;
                                 input[4] = c2;
                                 input[5] = sh.getShapeX();
                                 input[6] = sh.getShapeY();
                                 circleintersection(input,output);
                                 x = (int)output[0] - x;
                                 y = (int)output[1] - y;
                              //System.out.println(input[0]+" "+input[1]+" "+input[2]+" "+input[3]+" "+input[4]+" "+input[5]+" "+input[6]);
                                 sh.doMove(x,y,false);
                              }
                              ResolveSimpleConstraints(sh,cons);
                           }
                     }
                  }
               }
               break;
         
            default: res = false;
         }
      
         return res;
      }
   
      public static float distance(int x1, int y1, int x2, int y2)
      {
         return (float)java.lang.Math.sqrt(java.lang.Math.pow((double)(x1-x2),2)+java.lang.Math.pow((double)(y1-y2),2));
      }
   
      public static boolean lineintersection( double array[], double slope1, double slope2, double c1, double c2 )
      
      {
         //System.out.println(slope1+" "+slope2+" "+c1+" "+c2);
         array[0] = (c2 - c1) / (slope1 - slope2);
         array[1] = ( (slope1*c2) - (slope2*c1) ) / ( slope1 - slope2);
         if((slope1==0) || (slope2==0))
            return false;
         else
            return true;
      }
   
   
      public static void circleintersection( double input[], double output[])
      
      {
         int x=(int)input[0], y=(int)input[1], px=(int)input[5], py=(int)input[6];
         double m=input[3], c=input[4],a1,a2,x1,x2,y1,y2,r;
         float dist1,dist2;
         if(input[2]==-1)
            r = 20;
         else r = input[2];
         a1 = ((2*x) - (2*m*c) + (2*m*y)) / ((m*m) +1);
         a2 = ((x*x) + (c*c) -(2*y*c) + (y*y) - (r*r)) / ((m*m) +1);
         x1 = (a1 + java.lang.Math.sqrt((a1*a1) - (4*a2)) )/2;
         x2 = (a1 - java.lang.Math.sqrt((a1*a1) - (4*a2)) )/2;
         y1 = (m*x1) +c;
         y2 = (m*x2) +c;
         dist1 = distance((int)x1,(int)y1,px,py);
         dist2 = distance((int)x2,(int)y2,px,py);
         if(dist1<dist2)
         { 
            output[0] = x1;
            output[1] = y1;
         }
         else
         { 
            output[0] = x2;
            output[1] = y2;
         }
        // System.out.println(x+" m "+m+" c "+c+" y "+y+" r "+r);
         //System.out.println(a1+" a2 "+a2);
         //System.out.println(x1+" y1 "+y1+" x2 "+x2+" y2 "+y2);
      }
   
      public static SKBaseShape getOtherShape(SKBaseConstraint con, SKBaseShape sh)
      {
         if( (SKBaseShape) con.ShapeList.get(0) == sh)
            return (SKBaseShape) con.ShapeList.get(1);
         else 
            return (SKBaseShape) con.ShapeList.get(0);
      }
   }