/**
 * Title:        SKUTUFile
 * Description:  Methods to create file for UTU
 */
   package sketcher;

   import java.awt.Container;
   import java.awt.Point;
   import java.io.*;
   import utuJava;

   public class SKUTUFile
   {
      static int dataInt[];
      static double dataDouble[];
      static SKGTNArray dag=null;
      static int actCluster=0, intArraySize=0, doubleArraySize=0,indexInt=0,indexDbl=0;
      public static void waitForUpdate(SKShapeArray shapes,SKMainFrame frame, int width, int height )
      
      {
         int wid = width,
         hgt = height,
         w = width >> 1,
         h = height >> 1;
         int maxX,minX,maxY,minY;
         SKGroupTreeNode root = null;
         SKShapeArray allShapes = new SKShapeArray(10);
         shapes.copyArrayTo(allShapes);
         SKGroupTreeNode enode = null;
         maxX = -999;
         minX = 999;
         maxY = -999;
         minY = 999;
         int g,x,y,x3=0,y3=0,x2=0,y2=0,count=shapes.size(),number;
         double num1=0,num2=0;
         SKBaseShape sh;
         boolean done=false;
         TreeFrame clusters=null;
         utuJava utuDriver = new utuJava();
         indexInt = 0;
         int dagdata= dataInt[indexInt++];
         int length ;
      
         while (!done)
         {
         
            dag = new SKGTNArray(10);
            if(dagdata == -2)
            {
               int numRoots= dataInt[indexInt++];
               int ClusterID = dataInt[indexInt++];
               while(ClusterID != -1)
               {  boolean isPresent=false;
                  for(int n=0; n<dag.size(); n++)
                     isPresent= isPresent || (dag.get(n).ID==ClusterID);
                  if(!isPresent)
                  {SKGroupTreeNode node = new SKGroupTreeNode(null,ClusterID,"Group"+ClusterID);
                     dag.add(node);
                     enode = (SKGroupTreeNode)node;}
                  else                            
                     for(int n=0; n<dag.size(); n++) 
                        if(dag.get(n).ID==ClusterID)
                           enode = (SKGroupTreeNode)dag.get(n);
               
                  int ssize= dataInt[indexInt++];
               
                  SKShapeArray Shapes = new SKShapeArray(ssize);
                  for(int m=0; m<ssize; m++)
                  {int SID = dataInt[indexInt++];
                     SKBaseShape shape = (SKBaseShape)frame.allshapes.findByID(SID);
                     Shapes.add(shape);
                  }
                  Shapes.copyArrayTo(enode.shapes);
                  int numChildren = dataInt[indexInt++];
                  for(int m=0; m<numChildren; m++)
                  {ClusterID = dataInt[indexInt++];
                     isPresent=false;
                     for(int n=0; n<dag.size(); n++)
                        isPresent= isPresent || (dag.get(n).ID==ClusterID);
                     if(!isPresent)
                     {SKGroupTreeNode node1 = new SKGroupTreeNode(enode,ClusterID,"Cluster"+ClusterID);
                        enode.children.add(node1);
                        dag.add(node1);}
                     else 
                        for(int n=0; n<dag.size(); n++) 
                           if(dag.get(n).ID==ClusterID)
                              enode.children.add(dag.get(n));
                  
                  }
                  ClusterID = dataInt[indexInt++];
               }
               for(int l=0; l<dag.size(); l++)
                  for(int m=0; m<dag.get(l).children.size(); m++)
                     for( int n =0 ; n<dag.size(); n++)
                        if(dag.get(n)==dag.get(l).children.get(m))
                           dag.get(n).parents.add(dag.get(l));
            
               for(int l=0; l<dag.size(); l++)
                  if (dag.get(l).parents.size()==0)
                     root = dag.get(l);
            
            
               dataInt[0] = 1;
               utuDriver.utuC(dataInt, dataDouble);
            
            }
            //Solved, parse and update shapes
            if(dagdata !=-2)
            {
               wid = width;
               hgt = height;
               int numSolutions = dagdata;
               boolean first=true;
               if(numSolutions == 1)
               {
                  int i;
                  number = dataInt[indexInt++];
                  for(i=1;i<=number;i++)
                  {
                  //g = Integer.parseInt( p.readLine() );
                     g = dataInt[indexInt++];
                     sh = shapes.findByID(g);
                  
                  //num1 = Double.parseDouble( p.readLine() );
                  //num2 = -Double.parseDouble( p.readLine() );
                     num1 = dataDouble[indexDbl++];
                     num2 = dataDouble[indexDbl++];
                  
                     x = (int)java.lang.Math.round( num1*40 ) + w;
                     y = (int)java.lang.Math.round( num2*40 ) + h;
                  
                     if (x > maxX)  maxX = x;
                     if (x < minX)  minX = x;
                     if (y > maxY)  maxY = y;
                     if (y < minY)  minY = y;
                     if (sh instanceof SKPointShape)
                     {
                        if(first)
                        {
                           x3=x;
                           y3=y;
                           x2=(int)sh.getShapeX();
                           y2=(int)sh.getShapeY();
                           first=false;
                        }  
                        else 
                        {
                           x=x2-(x3-x);
                           y=y2-(y3-y);
                           sh.setShapePoint(new Point(x,y));
                        }
                     }
                     else if (sh instanceof SKLineShape)
                     {
                        if(first)
                        {x3=x;
                           y3=y;
                           x2=(int)((SKLineShape)sh).pt1.getShapeX();
                           y2=(int)((SKLineShape)sh).pt1.getShapeY();
                           first=false;
                        }
                        else 
                        {
                           x=x2-(x3-x);
                           y=y2-(y3-y);
                           ((SKLineShape)sh).pt1.setShapePoint(new Point(x,y));
                           System.out.println(sh+"1 "+((SKLineShape)sh).pt1.getX()+" "+((SKLineShape)sh).pt1.getY());
                        }
                        num1 = dataDouble[indexDbl++];
                        num2 = dataDouble[indexDbl++];
                        x = (int)java.lang.Math.round( num1*40 ) + w;
                        y = (int)java.lang.Math.round( num2*40 ) + h;
                        x=x2-(x3-x);
                        y=y2-(y3-y);
                     
                        ((SKLineShape)sh).pt2.setShapePoint(new Point(x,y));
                        System.out.println(sh+"2 "+((SKLineShape)sh).pt2.getX()+" "+((SKLineShape)sh).pt2.getY());
                        //int scale = Integer.parseInt( p.readLine() );
                        if (x > maxX)  maxX = x;
                        if (x < minX)  minX = x;
                        if (y > maxY)  maxY = y;
                        if (y < minY)  minY = y;
                     }
                     else if (sh instanceof SKCircleShape)
                     {
                        if(first)
                        {
                           x3=x;
                           y3=y;
                           x2=(int)((SKCircleShape)sh).center.getShapeX();
                           y2=(int)((SKCircleShape)sh).center.getShapeY();
                           first=false;
                        }
                        else 
                        {
                           x=x2-(x3-x);
                           y=y2-(y3-y);
                           ((SKCircleShape)sh).center.setShapePoint(new Point(x,y));
                           ((SKCircleShape)sh).radius = dataDouble[indexDbl++];
                        }
                     }
                  //Update sketch so it fits on screen
                     int delta = maxX-minX;
                     if ((maxY-minY) > delta)
                     {
                        delta = maxY-minY + 10;
                        if (delta > height)
                        {
                           frame.doScale(height/delta);
                           delta = height/delta;
                           maxX *= delta;
                           minX *= delta;
                           maxY *= delta;
                           minY *= delta;
                        }
                     }
                     else
                     {
                        delta += 10;
                        if (delta > width)
                        {
                           frame.doScale(width/delta);
                           delta = height/delta;
                           maxX *= delta;
                           minX *= delta;
                           maxY *= delta;
                           minY *= delta;
                        }
                     }
                     /*
                     if (minX < 0)
                     frame.doTranslate(-minX,0);
                     else if (maxX > 0)
                     frame.doTranslate(-maxX,0);
                     
                     if (minY < 0)
                     frame.doTranslate(-minY,0);
                     else if (maxY > 0)
                     frame.doTranslate(-maxY,0);*/
                     done = true;
                  }
               }
               else 
               {
                  length = dagdata;
                  SKBifurFrame dlg = new SKBifurFrame(frame,"Bifurcations",true);
                  indexInt=indexInt+length;
                  actCluster = dataInt[indexInt++]; 
                  clusters = new TreeFrame(frame,dag,actCluster);
                  clusters.setLocation(650,450);
                  clusters.show();
                  dlg.bifurcations = new SKBifurcationArray(5);
                  dlg.bifurcations.readFromStream(dataInt,dataDouble,indexInt,indexDbl,numSolutions,allShapes,frame,dlg.pnlShapes);
                  dlg.setLocation(0,450);
                  //Show the dialog
                  dlg.show();
                  boolean canFix=true;
                  for(int i=0; i<root.children.size(); i++)
                     if(actCluster==root.children.get(i).ID) canFix=false;
                  for(int i= 0; i<dlg.pnlShapes.getComponentCount(); i++)
                  {SKBaseShape sh1= (SKBaseShape)dlg.pnlShapes.getComponent(i);
                     if(canFix) frame.allshapes.findByID(sh1.ID).fixed=true;}
               
                  //Create output file to return index of selected bifurcation
                  int c = dataInt.length;
                  dataInt[c] = dlg.currBifurcation;
                  dataInt[0] = 1;
                  utuDriver.utuC(dataInt, dataDouble);
                  clusters.hide();
               }
            }
         }
      }
      public static void writeUTUFile(SKShapeArray shapes, SKGroupTreeNode groupRoot)
      {  
         intArraySize = 18*shapes.size();
         doubleArraySize = 3*shapes.size();
         dataInt = new int[intArraySize];
         dataInt[indexInt++]=0; //flag for UTU
         dataDouble = new double[doubleArraySize];
      
      	//Write shape list
         SKBaseShape sh,tmp;
         int i,g,h;
         for (i=0; i<shapes.size(); i++)
         {
            sh = (SKBaseShape)shapes.get(i);
            switch(sh.ShapeTypeID)
            {
               case 3:
                  SKLineShape line = (SKLineShape)sh;
                        //Write TypeID based if Segment,Ray,Line
                  switch (line.pt1.pointType+line.pt2.pointType)
                  {
                     case 0: dataInt[indexInt++]=3; //Segment
                           //System.out.println("typeID"+3);
                        break;
                     case 1: dataInt[indexInt++]=2; //Ray
                        break;
                     case 2: dataInt[indexInt++]=1; //Line (infinite)
                  }
                  break;
               default:
                  dataInt[indexInt++]=sh.ID;
                  break;
            }
         
            switch (sh.ShapeTypeID)
            {
            
               case 0:
                  {dataInt[indexInt++]=sh.getShapeX();
                     dataInt[indexInt++]=sh.getShapeY();}
                  break;
               case 3 : 
                  { //SKLineShape
                        //p.writeInt(888);
                     SKLineShape line = (SKLineShape)sh;
                     dataInt[indexInt++]=line.pt1.getShapeX();
                     dataInt[indexInt++]=line.pt1.getShapeY();
                     dataInt[indexInt++]=line.pt2.getShapeX();
                     dataInt[indexInt++]=line.pt2.getShapeY();
                     dataDouble[indexDbl++]=line.length;
                        //p.writeInt(999);
                  }
                  break;
               case 4 : 
                  { //SKCircleShape
                     dataDouble[indexDbl++]= ((SKCircleShape)sh).center.getShapeX();
                     dataDouble[indexDbl++]=((SKCircleShape)sh).center.getShapeY() ;
                     dataDouble[indexDbl++]=((SKCircleShape)sh).radius ;
                  }
                  break;
               case 5:
                  {
                     dataDouble[indexDbl++]=((SKArcShape)sh).center.getShapeX();
                     dataDouble[indexDbl++]=((SKArcShape)sh).center.getShapeY();
                     dataDouble[indexDbl++]=((SKArcShape)sh).radius;
                     dataDouble[indexDbl++]=((SKArcShape)sh).angle;
                  }
                  break;
               default: 
                  break;
            
            }
         
         }
      
      //Signify end of shape list
         dataInt[indexInt++]=-1;
      //p.writeInt(-1);
      
      //Write constraint list
         SKBaseConstraint con;
         SKConstraintArray Cons= new SKConstraintArray(100);
         for (i=0; i<shapes.size(); i++)
         {
            sh = (SKBaseShape)shapes.get(i);
         
            for (h=0; h<sh.ConstraintList.size(); h++)
            {
               con = sh.ConstraintList.get(h);
               if (con.isPrimaryShape(sh) && Cons.indexOf(con)==-1)
               {
                  Cons.add(con);
                  dataInt[indexInt++]=con.typeID;
                  //p.writeInt(con.typeID);
                  dataInt[indexInt++]=con.ID;
                  //p.writeInt(con.ID);
                  dataInt[indexInt++]=con.ShapeList.size();
                  //p.writeInt(con.ShapeList.size());
                  if (con instanceof SKNormalConstraint)
                  { //CAN consist of specific subshapes
                     for (g=0; g<con.ShapeList.size(); g++)
                     {
                        tmp = con.ShapeList.get(g);
                        dataInt[indexInt++]=tmp.ID;
                        //p.writeInt(tmp.ID);
                        dataInt[indexInt++]=con.getConInfo(tmp,0);
                        //p.writeInt(con.getConInfo(tmp,0));
                     }
                  
                     switch (con.typeID)
                     {
                        case 0: dataDouble[indexDbl++]=((SKDistanceConstraint)con).distance;
                           //p.writeDouble( ((SKDistanceConstraint)con).distance );
                           break;
                        case 4: dataDouble[indexDbl++]=((SKAngleConstraint)con).angle;
                        //p.writeDouble( ((SKAngleConstraint)con).angle );
                     }
                  }
                  else
                  { //Cannot consist of specific subshapes
                     for (g=0; g<con.ShapeList.size(); g++)
                        dataInt[indexInt++]=con.ShapeList.get(g).ID;
                     //p.writeInt(con.ShapeList.get(g).ID);
                  }
               }
            }
         
         }
      
      //Signify end of constraint list
         dataInt[indexInt++]=-1;
      //p.writeInt(-1);
      
      //Write group list
         indexInt=groupRoot.saveToUTUFile(indexInt, dataInt);
      
      //Signify end of group list (and file)
         dataInt[indexInt++]=-1;
      //p.writeInt(-1);
         utuJava utuDriver = new utuJava();
         utuDriver.utuC(dataInt, dataDouble);
      }
   
   
   }