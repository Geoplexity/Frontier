/**
 * Title:        SKBifurFrame
 * Description:  Frame used to display bifurcations
 */
   package sketcher;
   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
   import java.awt.Graphics;

   public class SKBifurFrame extends JDialog
   {
      public SKMainFrame frameMain;
      public int currBifurcation = -1;
      public SKBifurcationArray bifurcations;
      public  int               lastHorizScroll = 0,lastVertScroll = 0;
      public float              lastScale = 1;
      public JButton btnPrevious = new JButton();
      public JLabel lblStatus = new JLabel();
      public JButton btnNext = new JButton();
      public JPanel pnlBifurButtons = new JPanel();
      public JPanel pnlMain = new JPanel();
      public JSelectionPanel pnlShapes = new JSelectionPanel(frameMain);
      public BorderLayout borderLayout1 = new BorderLayout();
      public JScrollBar scrVert = new JScrollBar();
      public JScrollBar scrHoriz = new JScrollBar();
      public JPanel pnlControls = new JPanel();
      public JComboBox cmbScale = new JComboBox();
      public JLabel lblScale = new JLabel();
      public JPanel pnlButtons = new JPanel();
      public BorderLayout borderLayout2 = new BorderLayout();
      public JPanel pnlConfirm = new JPanel();
      public JButton btnConfirm = new JButton();
      public  int horvalue = 0;
      public  int vervalue = 0;
   
      public SKBifurFrame(Frame owner, String title, boolean modal)
      {
         super(owner,title,modal);
         frameMain = (SKMainFrame)owner;
         pnlShapes = new JSelectionPanel(frameMain);
         try
         {
            jbInit();
            setSize(600,550);
         //Center on desktop
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension d = getSize();
            int x = (screen.width - d.width) >> 1;
            int y = (screen.height - d.height) >> 1;
           // setLocation(x, y);
         }
            catch(Exception e)
            {
               e.printStackTrace();
            }
      
      }
   
   
      private void jbInit() throws Exception
      {
         pnlMain.setLayout(borderLayout1);
         scrHoriz.setOrientation(JScrollBar.HORIZONTAL);
         scrHoriz.addAdjustmentListener(
                                 new java.awt.event.AdjustmentListener()
                                 {
                                 
                                    public void adjustmentValueChanged(AdjustmentEvent e)
                                    {
                                       scrHoriz_adjustmentValueChanged(e);
                                    }
                                 });
         scrVert.addAdjustmentListener(
                                 new java.awt.event.AdjustmentListener()
                                 {
                                 
                                    public void adjustmentValueChanged(AdjustmentEvent e)
                                    {
                                       scrVert_adjustmentValueChanged(e);
                                    }
                                 });
         btnPrevious.setText("Previous");
         btnPrevious.addActionListener(
                              
                                 new java.awt.event.ActionListener()
                                 
                                 {
                                 
                                 
                                    public void actionPerformed(ActionEvent e)
                                    
                                    {
                                       btnPrevious_actionPerformed(e);
                                    }
                                 });
         lblStatus.setText(" Bifurcation 1 / N ");
         btnNext.setText("Next");
         btnNext.addActionListener(
                              
                                 new java.awt.event.ActionListener()
                                 
                                 {
                                 
                                 
                                    public void actionPerformed(ActionEvent e)
                                    
                                    {
                                       btnNext_actionPerformed(e);
                                    }
                                 });
      
         pnlShapes.setLayout(null);
         cmbScale.setEditable(true);
         cmbScale.addItemListener(
                                 new java.awt.event.ItemListener()
                                 {
                                 
                                    public void itemStateChanged(ItemEvent e)
                                    {
                                       cmbScale_itemStateChanged(e);
                                    }
                                 });
         lblScale.setText("Scale");
         pnlMain.setBorder(BorderFactory.createLoweredBevelBorder());
         pnlButtons.setLayout(borderLayout2);
         btnConfirm.setText("Select Bifurcations");
         btnConfirm.addActionListener(
                                 new java.awt.event.ActionListener()
                                 {
                                 
                                    public void actionPerformed(ActionEvent e)
                                    {
                                       btnConfirm_actionPerformed(e);
                                    }
                                 });
         this.addWindowListener(
                                 new java.awt.event.WindowAdapter()
                                 {
                                 
                                    public void windowOpened(WindowEvent e)
                                    {
                                       this_windowOpened(e);
                                    }
                                 });
         pnlBifurButtons.add(btnPrevious, null);
         pnlBifurButtons.add(lblStatus, null);
         pnlBifurButtons.add(btnNext, null);
         pnlButtons.add(pnlConfirm, BorderLayout.SOUTH);
         pnlConfirm.add(btnConfirm, null);
         this.getContentPane().add(pnlMain, BorderLayout.CENTER);
         pnlMain.add(pnlShapes, BorderLayout.CENTER);
         pnlMain.add(scrVert, BorderLayout.EAST);
         pnlMain.add(scrHoriz, BorderLayout.SOUTH);
         this.getContentPane().add(pnlControls, BorderLayout.NORTH);
         pnlControls.add(lblScale, null);
         pnlControls.add(cmbScale, null);
         pnlButtons.add(pnlBifurButtons, BorderLayout.CENTER);
         this.getContentPane().add(pnlButtons, BorderLayout.SOUTH);
      
         scrHoriz.setValues(0,pnlShapes.getWidth(),-1000,1000);
         scrHoriz.setUnitIncrement(10);
         scrVert.setValues(0,pnlShapes.getHeight(),-1000,1000);
         scrVert.setUnitIncrement(10);
      
         for(int i=0; i<frameMain.scaleValues.length; i++)
            cmbScale.addItem(frameMain.scaleValues[i]);
         cmbScale.setSelectedIndex(1);
      
      }
   
      void this_windowOpened(WindowEvent e)
      
      {         
         setBifurcation(0);
      
         boolean yes=false; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null; 
         int count =0;
         JOptionPane dialog = null;
         for(int i=0; i<pnlShapes.getComponentCount();i++)
         {
            SKBaseShape try1 = (SKBaseShape)pnlShapes.getComponent(i);
            int id = try1.ID;
            SKBaseShape try2 = frameMain.allshapes.findByID(id);
            if(try2 instanceof SKCircleShape) ((SKCircleShape)try2).bifur=true;
            if(try2 instanceof SKArcShape) ((SKArcShape)try2).bifur=true;
            if(try2.fixed==true){yes = true;
               fix=(SKBaseShape)pnlShapes.getComponent(i);
               fix1 = frameMain.allshapes.findByID(fix.ID);
               count++;
            }
            frameMain.solvingShapes.add(try1);
         }
         repaint();
         if(count>1)
            dialog.showMessageDialog(frameMain.panelShapeArea,"can not display partially solved sketch");
         /*int x,y,w,h; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null; 
         if(!yes)
         { fix=(SKBaseShape)pnlShapes.getComponent(0);
            fix1 = frameMain.allshapes.findByID(fix.ID);}
         for (int i=1; i<pnlShapes.getComponentCount();i++)
         {SKBaseShape sh = (SKBaseShape)pnlShapes.getComponent(i);
            int id = sh.ID;
            SKBaseShape sh1 = frameMain.allshapes.findByID(id);
            SKBifurcation bifur=bifurcations.get(currBifurcation);
            x=(fix.getShapeX()-sh.getShapeX());
            y=(fix.getShapeY()-sh.getShapeY());
            if(sh1.ID!=fix1.ID && !sh1.fixed)
               sh1.setLocation((fix1.getShapeX()-x-10),(fix1.getShapeY()-y-10));
            sh1.repaint();
         }*/
      }
      public void paint(Graphics g)
      {
         super.paint(g);
         drawNames(g);
         return;
      }
      void drawNames(Graphics g)
      {
         for(int i=0; i<pnlShapes.getComponentCount(); i++)
         {
            SKBaseShape sh= (SKBaseShape) pnlShapes.getComponent(i);
            g.drawString(sh.Name.charAt(0)+""+sh.ID, sh.getX(), sh.getY()+80);}
      }
      void pnlShapes_mouseMoved(MouseEvent e)
      {
      //Update mouse coordinates on statusbar
      //sbStatus.updatePanelText(e.getX()+" , "+e.getY(),2);
         boolean wasNull = (frameMain.mouseOverItem==null);
         if (frameMain.mouseOverItem==null || !frameMain.mouseOverItem.getClonedItem().doHitTest(e.getX(),e.getY()) )
         {
            for (int i=0; i<frameMain.DrawnItems.size(); i++)
            {
               frameMain.mouseOverItem = frameMain.DrawnItems.get(i);
               if ( frameMain.mouseOverItem.getClonedItem().doHitTest(e.getX(),e.getY()) )
               {
                  frameMain.sbStatus.updatePanelText( frameMain.mouseOverItem.toString(),3);
                  pnlShapes.repaint();
                  return;
               }
            }
         
            frameMain.mouseOverItem=null;
            frameMain.sbStatus.updatePanelText("",3);
            if (!wasNull)  pnlShapes.repaint();
         }
      }
   
      void pnlShapes_mouseDragged(MouseEvent e)
      {
      /* For dragging DrawnItems (dragging lineShape by line)
      if (mouseOverItem != null && mouseOverItem instanceof SKBaseShape)
      { //Drag shape
      SKBaseShape sh = (SKBaseShape)mouseOverItem;
      if (sh.isSelected())
      {
        if (sh.DragState==-1)
        {
          sh.DragState = 0;
          sh.DragX = e.getX();
          sh.DragY = e.getY();
          sh.setCursor( Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR) );
        }
        else
        { //Draw as user is dragging
          sh.doMove(e.getX()-sh.DragX,e.getY()-sh.DragY,(SKOptions.byteOptions[ SKOptions.simpleSolverMode ]==2));
        }
      
        RefreshShapeArea();
      }
      }
      else
      { //Do selection rect
      */
         if (!pnlShapes.DrawSelRect)
         {
            pnlShapes.DrawSelRect = true;
         
            pnlShapes.StartX = e.getX();
            pnlShapes.StartY = e.getY();
         }
         else
         { //Draw selection rect
            pnlShapes.EndX = e.getX();
            pnlShapes.EndY = e.getY();
         
            pnlShapes.repaint();
         }
      //    }
      }
   
      void pnlShapes_mouseReleased(MouseEvent e)
      {
         if (frameMain.mouseOverItem != null && frameMain.mouseOverItem instanceof SKBaseShape)
            ((SKBaseShape)frameMain.mouseOverItem).DragState = -1;
      
         if (e.isPopupTrigger())
         {
            frameMain.popupShape.show(pnlShapes,e.getX(),e.getY());
            return;
         }
      
         if (pnlShapes.DrawSelRect)
         { //Selected shapes in rect and repaint
            if (!e.isControlDown()) frameMain.clearSelectedShapes(true,true);
         
            int sx,sy,ex,ey;
            if (pnlShapes.StartX<pnlShapes.EndX)
            {
               sx = pnlShapes.StartX;
               ex = pnlShapes.EndX;
            }
            else
            {
               sx = pnlShapes.EndX;
               ex = pnlShapes.StartX;
            }
            if (pnlShapes.StartY<pnlShapes.EndY)
            {sy = pnlShapes.StartY;
               ey = pnlShapes.EndY;
            }
            else
            {
               sy = pnlShapes.EndY;
               ey = pnlShapes.StartY;
            }
         
            SKBaseShape sh;
            for (int i=0; i<pnlShapes.getComponentCount(); i++)
            {
               sh = (SKBaseShape)pnlShapes.getComponent(i);
               if (sh.getX()>sx && (sh.getX()+sh.getWidth())<ex &&
                  sh.getY()>sy && (sh.getY()+sh.getHeight()<ey))
               {
                  frameMain.addSelectedShape(sh);
               }
            }
         
            pnlShapes.DrawSelRect=false;
            pnlShapes.repaint();
         }
      }
   
      void pnlShapes_mouseClicked(MouseEvent e)
      {
         if (e.isPopupTrigger())
         {
            return;
         }
      
         if (frameMain.mouseOverItem != null)
         {
            if (frameMain.mouseOverItem instanceof SKBaseShape)
            {
               if (e.isControlDown())
                  frameMain.toggleSelectedShape((SKBaseShape)frameMain.mouseOverItem);
               else
                  frameMain.addOnlySelectedShape((SKBaseShape)frameMain.mouseOverItem);
            }
            else
               frameMain.EditConstraint( (SKBaseConstraint)frameMain.mouseOverItem );
         
            return;
         }
      }
   
      void scrVert_adjustmentValueChanged(AdjustmentEvent e)
      {
         doTranslate(0,lastVertScroll-e.getValue());
         set_vervalue(scrVert.getValue());
      }
   
      void scrHoriz_adjustmentValueChanged(AdjustmentEvent e)
      {
         doTranslate(lastHorizScroll-e.getValue(),0);
         set_horvalue(scrHoriz.getValue());
      }
   
      void cmbScale_itemStateChanged(ItemEvent e)
      {
         if (e.getStateChange()==e.SELECTED)
            doScale((Float.parseFloat(cmbScale.getSelectedItem().toString())) / 100);
      }
   
      void btnPrevious_actionPerformed(ActionEvent e)
      
      
      { 
         if (currBifurcation > 0)
            setBifurcation(currBifurcation-1);
         repaint();
         frameMain.repaint();
        /* int x,y,w,h; 
         boolean yes=false; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null; 
         int count =0;
         for(int i=0; i<pnlShapes.getComponentCount();i++)
         {
            SKBaseShape try1 = (SKBaseShape)pnlShapes.getComponent(i);
            int id = try1.ID;
            SKBaseShape try2 = frameMain.allshapes.findByID(id);
            if(try2.fixed==true){yes = true;
               fix=(SKBaseShape)pnlShapes.getComponent(i);
               fix1 = frameMain.allshapes.findByID(fix.ID);
               count++;
            }
         }
         if(!yes)
         { fix=(SKBaseShape)pnlShapes.getComponent(0);
            fix1 = frameMain.allshapes.findByID(fix.ID);}
      
         if (currBifurcation > 0)
         {
            setBifurcation(currBifurcation-1);
            for (int i=0; i<pnlShapes.getComponentCount();i++)
            {
               SKBaseShape sh = (SKBaseShape)pnlShapes.getComponent(i);
               int id = sh.ID;
               SKBaseShape sh1 = frameMain.allshapes.findByID(id);
               SKBifurcation bifur=bifurcations.get(currBifurcation);
               x=(fix.getShapeX()-sh.getShapeX());
               y=(fix.getShapeY()-sh.getShapeY());
               if(sh1.ID!=fix1.ID && !sh1.fixed)
                  sh1.setLocation((fix1.getShapeX()-x-10),(fix1.getShapeY()-y-10));
               sh1.repaint();
               frameMain.RefreshShapeArea();
            
            }
            }*/
         scrHoriz.setValue(horvalue);
         scrVert.setValue(vervalue);
      }
   
      void btnNext_actionPerformed(ActionEvent e)
      {  
         if (currBifurcation < bifurcations.size()-1)
            setBifurcation(currBifurcation+1);
         repaint();
         frameMain.repaint();
         /*int x,y,w,h;   
         boolean yes=false; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null; 
         int count =0;
         for(int i=0; i<pnlShapes.getComponentCount();i++)
         {
            SKBaseShape try1 = (SKBaseShape)pnlShapes.getComponent(i);
            int id = try1.ID;
            SKBaseShape try2 = frameMain.allshapes.findByID(id);
            if(try2.fixed==true){yes = true;
               fix=(SKBaseShape)pnlShapes.getComponent(i);
               fix1 = frameMain.allshapes.findByID(fix.ID);
               count++;
            }
         }
         if(!yes)
         { fix=(SKBaseShape)pnlShapes.getComponent(0);
            fix1 = frameMain.allshapes.findByID(fix.ID);}
      
         if (currBifurcation < bifurcations.size()-1)
         {
            setBifurcation(currBifurcation+1);
            for (int i=1; i<pnlShapes.getComponentCount();i++)
            {SKBaseShape sh = (SKBaseShape)pnlShapes.getComponent(i);
               int id = sh.ID;
               SKBaseShape sh1 = frameMain.allshapes.findByID(id);
               SKBifurcation bifur=bifurcations.get(currBifurcation);
               x=(fix.getShapeX()-sh.getShapeX());
               y=(fix.getShapeY()-sh.getShapeY());
               if(sh1.ID!=fix1.ID && !sh1.fixed)
                  sh1.setLocation((fix1.getShapeX()-x-10),(fix1.getShapeY()-y-10));
               sh1.repaint();
               frameMain.RefreshShapeArea();
            }                
         }*/
         scrHoriz.setValue(horvalue);
         scrVert.setValue(vervalue);
      
      }
   
      void btnConfirm_actionPerformed(ActionEvent e)
      {
        /* int x,y,w,h;    
         boolean yes=false; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null;  
         for(int i=0; i<pnlShapes.getComponentCount();i++)
         {
            SKBaseShape try1 = (SKBaseShape)pnlShapes.getComponent(i);
            int id = try1.ID;
            SKBaseShape try2 = frameMain.allshapes.findByID(id);
            if(try2.fixed==true){yes = true;
               fix=(SKBaseShape)pnlShapes.getComponent(i);
               fix1 = frameMain.allshapes.findByID(fix.ID);
            }
         }
         if(!yes)
         { fix=(SKBaseShape)pnlShapes.getComponent(0);
            fix1 = frameMain.allshapes.findByID(fix.ID);}
         for (int i=1; i<pnlShapes.getComponentCount();i++)
         {SKBaseShape sh = (SKBaseShape)pnlShapes.getComponent(i);
            int id = sh.ID;
            SKBaseShape sh1 = frameMain.allshapes.findByID(id);
            SKBifurcation bifur=bifurcations.get(currBifurcation);
            x=(fix.getShapeX()-sh.getShapeX());
            y=(fix.getShapeY()-sh.getShapeY());
            if(sh1.ID!=fix1.ID && !sh1.fixed)
               sh1.setLocation((fix1.getShapeX()-x-10),(fix1.getShapeY()-y-10));
            sh1.repaint();
         }*/
         for (int i=0; i<pnlShapes.getComponentCount();i++)
         {SKBaseShape sh = (SKBaseShape)pnlShapes.getComponent(i);
            int id = sh.ID;
            SKBaseShape sh1 = frameMain.allshapes.findByID(id);
            if( sh1 instanceof SKNormalShape)sh1.fixed=true;
            else 
               for(int a=0; a<sh1.getNumSubShapes()+1; a++)
                  sh1.getSubShape(a).fixed=true;
         }
      
         frameMain.solvingShapes.clear();
         frameMain.RefreshShapeArea();
         hide();
      }
   
   /////////////////////////////////////////////////////
   //
   //  Functionality
   //
   /////////////////////////////////////////////////////
   
      public void doScale(float newScale)
      {
         float delta = newScale/lastScale;
         Component cmp;
         for(int i=0; i<pnlShapes.getComponentCount(); i++)
         {
            cmp = pnlShapes.getComponent(i);
            cmp.setLocation( java.lang.Math.round(cmp.getX()*delta), java.lang.Math.round(cmp.getY()*delta) );
         }
      
         lastScale = newScale;
      }
   
      public void doTranslate(int deltaX, int deltaY)
      {
         //Component cmp;
         SKBaseShape cmp;
         for (int i=0; i<pnlShapes.getComponentCount(); i++)
         {
            cmp = (SKBaseShape)pnlShapes.getComponent(i);
            //System.out.println("before "+cmp+" "+cmp.getX()+" "+cmp.getY()+" "+deltaX+" "+deltaY);
            if(cmp instanceof SKNormalShape)cmp.setLocation(cmp.getX()+deltaX,cmp.getY()+deltaY);
            else 
               for(int a=1; a<cmp.getNumSubShapes()+1; a++)
                  cmp.setShapePoint(new Point(cmp.getX()+deltaX,cmp.getY()+deltaY));
            //System.out.println("after "+cmp+" "+cmp.getX()+" "+cmp.getY());
         }
         pnlShapes.repaint();
      
         if (deltaX != 0)  lastHorizScroll = lastHorizScroll - deltaX;
         if (deltaY != 0)  lastVertScroll = lastVertScroll - deltaY;
         repaint();
      }
   
      void set_vervalue(int i)
      {
         if(i!=0)vervalue = i;
      }
   
      void set_horvalue(int i)
      {
         if(i!=0)horvalue = i;
      }
      public void setBifurcation(int index)
      {
         if (currBifurcation == -1)
         { //Init display
            frameMain.clearSelectedShapes(true,true);
            for (int i=0; i<pnlShapes.getComponentCount(); i++)
               frameMain.addSelectedShape( ((SKBaseShape)pnlShapes.getComponent(i)).clonedShape );
               //frameMain.addSelectedShape( ((SKBaseShape)pnlShapes.getComponent(i)));
         
         }
      
         if (index != currBifurcation && index < bifurcations.size())
         {
            scrHoriz.setValue(0);
            scrVert.setValue(0);
            cmbScale.setSelectedIndex(1);
            bifurcations.updateShapes(index,this);
            for(int i=0; i<pnlShapes.getComponentCount(); i++)
               ((SKBaseShape)pnlShapes.getComponent(i)).repaint();
            pnlShapes.repaint();
            currBifurcation = index;
            lblStatus.setText(" Bifurcation "+(currBifurcation+1)+" / "+bifurcations.size()+" ");
         }
      
         frameMain.RefreshShapeArea();
         for(int i=0; i<frameMain.allshapes.size(); i++)
         {frameMain.allshapes.get(i).repaint();
         }
         boolean yes=false; 
         SKBaseShape fix = null;
         SKBaseShape fix1 = null;
         int x,y,w,h;  
         int count =0;
         for(int i=0; i<pnlShapes.getComponentCount();i++)
         {SKBaseShape try1 = (SKBaseShape)pnlShapes.getComponent(i);
            if(try1 instanceof SKCircleShape)
            {SKBaseShape try2 = frameMain.allshapes.findByID(try1.ID);
               if(!try2.fixed)
                  ((SKCircleShape)try2).radius =((SKCircleShape) try1).radius;
            }
         }
         for(int i=0; i<pnlShapes.getComponentCount();i++)
            for(int j=1; j<((SKBaseShape)pnlShapes.getComponent(i)).getNumSubShapes()+1;j++)
            {
               SKBaseShape try1 = ((SKBaseShape)pnlShapes.getComponent(i)).getSubShape(j);
               int id = ((SKBaseShape)pnlShapes.getComponent(i)).ID;
               SKBaseShape try2 = frameMain.allshapes.findByID(id).getSubShape(j);
               if(try2.fixed==true)
               {
                  yes = true;
                  fix=try1;
                  fix1 = try2;
                  count++;
               }
            }
         if(!yes)
         { fix=((SKBaseShape)pnlShapes.getComponent(0)).getSubShape(1);
            fix1 = (frameMain.allshapes.findByID(((SKBaseShape)pnlShapes.getComponent(0)).ID)).getSubShape(1);
         }
         for (int i=0; i<pnlShapes.getComponentCount();i++)
            for(int j=1; j<((SKBaseShape)pnlShapes.getComponent(i)).getNumSubShapes()+1;j++)
            {SKBaseShape sh = ((SKBaseShape)pnlShapes.getComponent(i)).getSubShape(j);
               if(sh.ID!=fix.ID)
               { int id =((SKBaseShape)pnlShapes.getComponent(i)).ID;
                  SKBaseShape sh1 = frameMain.allshapes.findByID(id).getSubShape(j);
                  SKBaseShape sh1P = frameMain.allshapes.findByID(id);
                  SKBifurcation bifur=bifurcations.get(currBifurcation);
                  x=(fix.getShapeX()-sh.getShapeX());
                  y=(fix.getShapeY()-sh.getShapeY());
                  if(sh1.ID!=fix1.ID && !sh1.fixed)
                  //sh1.setLocation((fix1.getShapeX()-x-10),(fix1.getShapeY()-y-10));
                     sh1.setShapePoint(new Point((fix1.getShapeX()-x),(fix1.getShapeY()-y)));
                  sh1P.repaint();}
            }
      }
   }