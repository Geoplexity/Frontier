   package sketcher;

   import javax.swing.*;
   import javax.swing.tree.*;
   import java.awt.event.*;
   import java.awt.*;
   import java.io.*;
   import java.awt.Color;
   import java.lang.String;
   import javax.swing.event.*;


   public class TreeFrame extends JFrame
   
   
   {
      public static SKMainFrame frame1;
      public static SKGTNArray Groups = new SKGTNArray(100);
      public static int ID,w,h;
      public static trycanvas try1 = new trycanvas();
      public static JScrollPane panelMain = new JScrollPane(try1);
   
      public JTree treeGroups = new JTree();
      public  SKShapeArray      selectedGroupShapes = new SKShapeArray(6);
      public  SKGTNArray        selectedGroups = new SKGTNArray(3);
      public SKGroupTreeNode      groupTree = new SKGroupTreeNode(null,-1,"Groups");
      public JPanel panelGroups = new JPanel();
      public BorderLayout borderLayout1 = new BorderLayout();
      public BorderLayout borderLayout3 = new BorderLayout();
      public int lastHorizScroll=0,lastVertScroll=0;
   
      public static void main (String argv[])
      
      { new TreeFrame(frame1,Groups,ID);
      }
   
      public TreeFrame(SKMainFrame frame, SKGTNArray allGroups, int actID) 
      
      {  
         super();
         try{
            jbInit();}
         
            catch(Exception e)
            {
               e.printStackTrace();
            }
         frame1=frame;
         w = frame.getSize().width;
         h = frame.getSize().height;
         allGroups.copyArrayTo(Groups);
         ID = actID;
         setSize(600,500);
         addWindowListener(new LocalWindowAdapter());
         this.getContentPane().add(panelMain, BorderLayout.CENTER);
         //this.getContentPane().add(panelGroups, BorderLayout.EAST);
         show();
      }
      private void jbInit() throws Exception
      
      {       
         panelGroups.setLayout(borderLayout3);
         treeGroups.getSelectionModel().setSelectionMode(javax.swing.tree.TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
         treeGroups.setModel(
                            
                            
                               new TreeModel()
                               
                               
                               {
                               
                                  public Object getChild(Object parent, int index)
                                  
                                  {
                                     return ((SKGroupTreeNode)parent).children.get(index);
                                  }
                               
                                  public int getChildCount(Object parent)
                                  
                                  {
                                     return ((SKGroupTreeNode)parent).children.size();
                                  }
                               
                                  public int getIndexOfChild(Object parent, Object child)
                                  
                                  
                                  {
                                     return ((SKGroupTreeNode)parent).children.indexOf(child);
                                  }
                               
                               
                                  public Object getRoot()
                                  
                                  
                                  {
                                     return groupTree;
                                  }
                               
                               
                                  public boolean isLeaf(Object node)
                                  
                                  
                                  {
                                     return (((SKGroupTreeNode)node).children.size() == 0);
                                  }
                               
                               
                                  public void valueForPathChanged(javax.swing.tree.TreePath path, Object newValue)
                                  
                                  
                                  {}
                               
                               
                                  public void addTreeModelListener(javax.swing.event.TreeModelListener l)
                                  
                                  
                                  {}
                               
                               
                                  public void removeTreeModelListener(javax.swing.event.TreeModelListener l)
                                  
                                  
                                  {}
                               });
         treeGroups.addMouseListener(
                              
                              
                                 new java.awt.event.MouseAdapter()
                                 {
                                 
                                    public void mouseClicked(MouseEvent e)
                                    {
                                       treeGroups_mouseClicked(e);
                                    }
                                 });
         treeGroups.updateUI();
         panelGroups.add(treeGroups);
      }
   
   
      void scrHoriz_adjustmentValueChanged(AdjustmentEvent e)
      
      {
         doTranslate(lastHorizScroll-e.getValue(),0);
      }
   
      void scrVert_adjustmentValueChanged(AdjustmentEvent e)
      
      {
         doTranslate(0,lastVertScroll-e.getValue());
      }
   
      public void doTranslate(int deltaX, int deltaY)
      
      {
         Component cmp;
         cmp=try1;
         cmp.setLocation(cmp.getX()+deltaX,cmp.getY()+deltaY);
         this.repaint();
      
         if (deltaX != 0)  lastHorizScroll = lastHorizScroll - deltaX;
         if (deltaY != 0)  lastVertScroll = lastVertScroll - deltaY;
      }
      public void clearSelectedGroups()
      
      {
         selectedGroups.clear();
      
         for(int i=0; i<selectedGroupShapes.size(); i++)
            selectedGroupShapes.get(i).highestGroup = null;
      
         selectedGroupShapes.clear();
         treeGroups.setSelectionPath(null);
      }
   
   
      public void RefreshShapeArea()
      
      {
         panelGroups.repaint();
      }
   
   
      void treeGroups_mouseClicked(MouseEvent e)
      
      {
      //Update group selection
         int i;
         for (i=0; i<selectedGroupShapes.size(); i++)
            selectedGroupShapes.get(i).highestGroup = null;
      
         for (i=0; i<selectedGroups.size(); i++)
            selectedGroups.get(i).groupRect.w = 0;
      
         selectedGroupShapes.clear();
         selectedGroups.clear();
      
         TreePath path;
         for (i=0; i<treeGroups.getSelectionCount(); i++)
         {
            path = treeGroups.getSelectionPaths()[i];
            if (path.getPathCount()>1)
            {
               selectedGroups.add( (SKGroupTreeNode)path.getLastPathComponent() );
               SKGroups.getAllGroupShapes( (SKGroupTreeNode)path.getLastPathComponent(), selectedGroupShapes, true );
            
            }
         }
      
         for (i=0; i<selectedGroupShapes.size(); i++)
            selectedGroupShapes.get(i).highestGroup = SKGroups.getHighestGroupWithShape(selectedGroupShapes.get(i),selectedGroups);
         panelGroups.repaint();
      }
   
   
      public static class trycanvas extends Canvas
      
      {
         int center = 0;
         SKGTNArray temp = new SKGTNArray(100);
         SKGTNArray final1 = new SKGTNArray(100);
         SKGTNArray root = new SKGTNArray(100);
         SKGTNArray children = new SKGTNArray(100);
         SKShapeArray exshapes = new SKShapeArray(100);
         String title = "god id the greatest";
         int x1,y1,x2,y2,total;
         private Color black = Color.black;
         private Color magenta = Color.magenta;
         private Color red = Color.red;
      
         public void paint(Graphics g)
         
         {
            Groups.copyArrayTo(temp);  
            for(int i=0; i< temp.size();i++)
            {    
               if(temp.get(i).parents.size()==0)
                  root.add(temp.get(i));
            }
         
            /*for(int i=0; i<root.size(); i++)
            {
               groupTree.children.add(root.get(i));
               root.get(i).parents.add(groupTree);
            }*/
            SKGTNArray tempgroups = new SKGTNArray(root.size());
            SKGTNArray temproots = new SKGTNArray(root.size());
            root.copyArrayTo(temproots);
            for(int i=0; i<temproots.size(); i++)
            {
               SKGroups.separateGroups(temproots.get(i),temp,tempgroups);
               int rootsize= temproots.get(i).shapes.size();
               for(int a=0; a<tempgroups.size(); a++)
               { 
                  int diff=rootsize-tempgroups.get(a).shapes.size();
                  tempgroups.get(a).width=((temproots.get(i).width)-50*diff);
               
               }
            
               tempgroups.clear();
            }
         
            for(int i=0; i< root.size();i++)
            {root.get(i).x= (this.getWidth()/(root.size()+1))*(i+1);
               root.get(i).y=50;
            
            }
            final1.clear();
            if(root.size()>0)
               for(int i=0;i<root.size();i++)
                  final1.add(root.get(i));
         
            while(root.size()>0)
            {SKGTNArray temproot = new SKGTNArray(100);
               for (int a=0; a<root.size(); a++)
                  for (int b=0; b<root.get(a).children.size(); b++)  
                  {
                     children.add(root.get(a).children.get(b));
                     temproot.add(root.get(a).children.get(b));
                  }
               if(temproot.size()>0)temproot.copyArrayTo(root);
               else root.clear();
            }
         
         
         
            if(children.size()>0)
               for(int i=0;i<children.size();i++)
                  //if(final1.indexOf(children.get(i))==-1)
                  final1.add(children.get(i));
         
            for(int i=0; i<final1.size();i++)
            {                     
               exshapes.clear(); 
               if(final1.get(i).children.size()>0)
               {       
                  SKShapeArray childshapes = new SKShapeArray(100);
                  for(int c = 0; c <final1.get(i).children.size();c++)
                     for(int b=0; b<final1.get(i).children.get(c).shapes.size();b++)
                        if(   childshapes.indexOf( final1.get(i).children.get(c).shapes.get(b) ) == -1 )
                           childshapes.add(final1.get(i).children.get(c).shapes.get(b));
               
                  if(final1.get(i).shapes.size()>childshapes.size())
                  {//SKShapeArray exshapes = new SKShapeArray(100);
                     for(int c=0; c<final1.get(i).shapes.size(); c++)
                        if(childshapes.indexOf(final1.get(i).shapes.get(c))==-1)
                           exshapes.add(final1.get(i).shapes.get(c));
                     total = final1.get(i).children.size()+exshapes.size();
                  }
               
                  for(int a=0; a<final1.get(i).children.size(); a++)
                  {    
                     final1.get(i).children.get(a).y= final1.get(i).y + 45;
                     if(exshapes.size()==0)
                        final1.get(i).children.get(a).x= (final1.get(i).x-(final1.get(i).width/2))+(  (final1.get(i).width/ (final1.get(i).children.size()+1) )*(a+1));
                     else final1.get(i).children.get(a).x= (final1.get(i).x-(final1.get(i).width/2))+((final1.get(i).width/(total+1))*(a+1));
                  }
               
               
                  if(exshapes.size()>0)
                     for(int b=0;b<exshapes.size();b++)
                     {
                        x1=final1.get(i).x;
                        y1=final1.get(i).y;
                        y2=final1.get(i).y+45;
                        int exsx=(final1.get(i).x-(final1.get(i).width/2))+((final1.get(i).width/(total+1))*(final1.get(i).children.size()+b+1));
                        g.setColor(black);
                        g.drawLine(x1,y1,exsx,y2);
                        g.setColor(red);
                        g.drawString(exshapes.get(b).Name.charAt(0)+""+exshapes.get(b).ID,exsx,y2);
                     }
               
               }
            }
            for(int i=0; i<final1.size();i++)
               for(int a = 0; a <final1.get(i).children.size();a++)
               {
                  x1=final1.get(i).x;
                  y1=final1.get(i).y;
                  x2=final1.get(i).children.get(a).x;
                  y2=final1.get(i).children.get(a).y;
                  g.setColor(black);
                  g.drawLine(x1,y1,x2,y2);
               }
            for(int i=0; i<final1.size(); i++)
            {
               if(final1.get(i).ID==ID)g.setColor(magenta);
               else g.setColor(black);
               if(final1.get(i).parents.size()==0)g.drawString(final1.get(i).name,final1.get(i).x,final1.get(i).y);
               else if(ID==0) g.drawString("G"+final1.get(i).ID,final1.get(i).x,final1.get(i).y);
               else g.drawString("C"+final1.get(i).ID,final1.get(i).x,final1.get(i).y);
               if(final1.get(i).children.size()==0)
               {int sx, sy;
                  for  (int a=0; a<final1.get(i).shapes.size(); a++)
                  { sy= final1.get(i).y +45;
                     if(final1.get(i).shapes.size()==1)  sx=final1.get(i).x;
                     else  sx= (final1.get(i).x-(final1.get(i).width/4))+(  ((final1.get(i).width/2)/ (final1.get(i).shapes.size()+1) )*(a+1));
                     g.setColor(black);
                     g.drawLine(final1.get(i).x,final1.get(i).y,sx,sy);
                     g.setColor(red);
                     g.drawString(final1.get(i).shapes.get(a).Name.charAt(0)+""+final1.get(i).shapes.get(a).ID,sx,sy);
                  
                  }
               }
            
            }
            final1.clear();
         }
      }
   
      class LocalWindowAdapter extends WindowAdapter
      {
         public void windowClosing(WindowEvent e)
         {hide();
            Groups.clear();
            return;
         }
      }
   
   }