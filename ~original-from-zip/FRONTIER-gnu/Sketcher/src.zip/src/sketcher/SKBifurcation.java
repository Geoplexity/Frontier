/**
 * Title:        SKBifurcation
 * Description:  Array of SKBifurAtom
 */
   package sketcher;

   public class SKBifurcation
   {
      public float[] data;
      public int     addX,addY;
      public float   scale = -1;
   
      public SKBifurcation()
      {
      }
   }