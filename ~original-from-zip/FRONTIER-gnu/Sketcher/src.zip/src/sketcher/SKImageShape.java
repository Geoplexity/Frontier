/**
 * Title:        SKImageShape
 * Description:  Shape for images
 */
   package sketcher;

   import java.awt.Graphics;
   import javax.swing.ImageIcon;
   import java.io.File;
   import java.io.DataOutputStream;
   import java.io.DataInputStream;
   import java.io.IOException;

   public class SKImageShape extends SKNormalShape
   {
      public  ImageIcon image;
      public  String    imageFile;
      private float     scale = 1;
   
      public SKImageShape(SKMainFrame frame, int newID, int x, int y)
      {
         super(frame,newID,"Image"+newID,"Image",6,x,y);
      
         imageFile = new String(frame.HomeDir+"/images/blankimage.gif");
         image = new ImageIcon(imageFile);
      
         IconPath = "/images/imageicon.gif";
         reshape(x-10,y-10,(int)(image.getIconWidth()*scale),(int)(image.getIconHeight()*scale));
      }
   
      public void updateMainShapeData(SKPropArray vPropList, SKConstraintArray vCurrentConstraints)
      {
         super.updateMainShapeData(vPropList,vCurrentConstraints);
      
         if (vPropList != null)
         { //Update properties
            vPropList.add(frameMain.propFactory.getNewProp("Scale", Float.toString( scale*100 ),1));
            vPropList.add(frameMain.propFactory.getNewProp("ImageFile", imageFile, 1));
         }
      }
   
      public boolean setShapeData(String PropName, Object PropData)
      {
         if (super.setShapeData(PropName,PropData))  
            return true;
      
         if (PropName=="Scale")
         {
            scale = Float.parseFloat(PropData.toString()) / 100;
            reshape(getX(),getY(),(int)(image.getIconWidth()*scale),(int)(image.getIconHeight()*scale));
         }
         else if (PropName=="ImageFile")
         {
            if (new File(PropData.toString()).exists())
            {
               imageFile = PropData.toString();
               image = new ImageIcon(imageFile);
               reshape(getX(),getY(),(int)(image.getIconWidth()*scale),(int)(image.getIconHeight()*scale));
            }
         }
         else 
            return false;
      
         return true;
      }
   
      public void paintComponent(Graphics g)
      {
         if (shouldDraw())
         {
            updateColors();
         
            g.drawImage(image.getImage(),1,1,getWidth()-2,getHeight()-2,null);
         
            g.setColor(outlineColor);
            g.drawRect(0,0,getWidth()-1,getHeight()-1);
         }
      }
   
      public void writeAdditionalProps(DataOutputStream p) throws IOException
      {
         super.writeAdditionalProps(p);
      
         p.writeUTF( imageFile );
         p.writeFloat( scale );
      }
   
      public void readAdditionalProps(DataInputStream p) throws IOException
      {
         super.readAdditionalProps(p);
      
         imageFile = p.readUTF();
         scale = p.readFloat();
      
         if (!(new File(imageFile).exists()))
            imageFile = frameMain.HomeDir+"/blankimage.gif";
      
         image = new ImageIcon(imageFile);
         reshape(getX(),getY(),(int)(image.getIconWidth()*scale),(int)(image.getIconHeight()*scale));
      }
   }